//ready-made config.h for a quick 'n dirty Windows build
#define PACKAGE "tuxmath"
#define PACKAGE_BUGREPORT "tuxmath-devel@lists.sourceforge.net"
#define PACKAGE_NAME "Tux Of Math Command"

