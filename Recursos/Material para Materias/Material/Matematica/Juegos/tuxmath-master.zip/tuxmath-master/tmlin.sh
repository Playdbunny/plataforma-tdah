# An 'all-in-one' script to build and install on the Linux host:

make clean
make distclean
./autogen.sh
./configure
make
make install


