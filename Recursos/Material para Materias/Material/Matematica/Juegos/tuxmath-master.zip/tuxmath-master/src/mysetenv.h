//
// C Interface: mysetenv
//
// Description: example code from GNU Gettext FAQ.
// This code is in the public domain.
//



#ifndef MY_SETENV_H
#define MY_SETENV_H

int my_setenv(const char * name, const char * value);

#endif
